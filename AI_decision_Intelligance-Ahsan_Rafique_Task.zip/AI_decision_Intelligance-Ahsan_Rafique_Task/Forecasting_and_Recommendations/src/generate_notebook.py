import json
from pathlib import Path

null = None

notebook_content = {
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# AI Decision Intelligence & What-If Simulator\n",
    "## Task: Daily Sales Revenue Forecasting & Business Recommendations\n",
    "\n",
    "**Prepared by:** Ahsan Rafique  \n",
    "**Role:** AI Engineer (Internship at Codecelix)  \n",
    "**Methodology:** PACE Framework (Plan, Analyze, Construct, Execute)  \n",
    "**Target Variable:** Daily Net Sales Revenue (`net_sales_gbp`)  \n",
    "**Dataset:** UCI Online Retail (Preprocessed Daily Time-Series)  \n",
    "**Primary Model:** Random Forest Regressor (with Lag, Rolling, and Calendar features)  \n",
    "**Benchmark Baseline:** 7-Day Moving Average"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 1. Imports and Setup"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "from pathlib import Path\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "import json\n",
    "\n",
    "from sklearn.ensemble import RandomForestRegressor\n",
    "from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score\n",
    "\n",
    "# File paths\n",
    "BASE_DIR = Path(\"..\").resolve()\n",
    "DATA_PATH = BASE_DIR.parent / \"AI_decision_Intelligance-Abdul_Samad_Task\" / \"Dataset_Sourcing_and_Data_Cleaning\" / \"preprocessed_datasets\" / \"processed_datasets_bundle\" / \"online_retail_daily_sales.csv\"\n",
    "\n",
    "print(\"Data source located:\", DATA_PATH.exists())\n",
    "df = pd.read_csv(DATA_PATH)\n",
    "df['date'] = pd.to_datetime(df['date'])\n",
    "df = df.sort_values('date').reset_index(drop=True)\n",
    "df.head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 2. Exploratory Data Analysis & Weekly Patterns"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "print(f\"Total days: {len(df)}\")\n",
    "print(f\"Date span: {df['date'].min().date()} to {df['date'].max().date()}\")\n",
    "print(\"\\nSummary Statistics of Net Daily Sales (£):\")\n",
    "display(df[['net_sales_gbp', 'gross_sales_gbp', 'net_quantity', 'invoices']].describe())\n",
    "\n",
    "# Check Saturday zero-sales\n",
    "df['day_name'] = df['date'].dt.day_name()\n",
    "day_group = df.groupby('day_name')['net_sales_gbp'].mean().reindex([\n",
    "    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'\n",
    "])\n",
    "print(\"\\nAverage Net Daily Sales by Day of Week:\")\n",
    "print(day_group)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 3. Feature Engineering for Time-Series ML\n",
    "Random Forest requires explicit temporal features. We construct:\n",
    "- **Lags:** $t-1, t-2, t-3, t-7, t-14$\n",
    "- **Rolling Stats:** 7-day and 14-day rolling averages and standard deviation\n",
    "- **Calendar:** `day_of_week`, `day_of_month`, `month`, `is_weekend`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "data = df.copy()\n",
    "target_col = 'net_sales_gbp'\n",
    "\n",
    "# Calendar features\n",
    "data['day_of_week'] = data['date'].dt.dayofweek\n",
    "data['day_of_month'] = data['date'].dt.day\n",
    "data['month'] = data['date'].dt.month\n",
    "data['is_weekend'] = data['day_of_week'].isin([5, 6]).astype(int)\n",
    "\n",
    "# Lag features\n",
    "for lag in [1, 2, 3, 7, 14]:\n",
    "    data[f'lag_{lag}'] = data[target_col].shift(lag)\n",
    "\n",
    "# Rolling statistics (shifted by 1 to prevent data leakage)\n",
    "data['rolling_mean_7'] = data[target_col].shift(1).rolling(window=7, min_periods=7).mean()\n",
    "data['rolling_std_7'] = data[target_col].shift(1).rolling(window=7, min_periods=7).std()\n",
    "data['rolling_mean_14'] = data[target_col].shift(1).rolling(window=14, min_periods=14).mean()\n",
    "\n",
    "# Drop initial NaN rows\n",
    "clean_data = data.dropna().reset_index(drop=True)\n",
    "print(\"Engineered dataset shape:\", clean_data.shape)\n",
    "clean_data.head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 4. Chronological Train-Test Split (Last 30 Days as Test)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "test_days = 30\n",
    "feature_cols = [\n",
    "    'day_of_week', 'day_of_month', 'month', 'is_weekend',\n",
    "    'lag_1', 'lag_2', 'lag_3', 'lag_7', 'lag_14',\n",
    "    'rolling_mean_7', 'rolling_std_7', 'rolling_mean_14'\n",
    "]\n",
    "\n",
    "train_df = clean_data.iloc[:-test_days].copy()\n",
    "test_df = clean_data.iloc[-test_days:].copy()\n",
    "\n",
    "X_train, y_train = train_df[feature_cols], train_df[target_col]\n",
    "X_test, y_test = test_df[feature_cols], test_df[target_col]\n",
    "\n",
    "print(f\"Train period: {train_df['date'].min().date()} to {train_df['date'].max().date()} ({len(train_df)} days)\")\n",
    "print(f\"Test period:  {test_df['date'].min().date()} to {test_df['date'].max().date()} ({len(test_df)} days)\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 5. Model Training & Evaluation Benchmark\n",
    "- **Baseline:** 7-Day Moving Average  \n",
    "- **Hero Model:** Random Forest Regressor"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "# 1. Baseline Evaluation\n",
    "baseline_pred = test_df['rolling_mean_7']\n",
    "baseline_mae = mean_absolute_error(y_test, baseline_pred)\n",
    "baseline_rmse = np.sqrt(mean_squared_error(y_test, baseline_pred))\n",
    "\n",
    "# 2. Random Forest Regressor\n",
    "rf_model = RandomForestRegressor(\n",
    "    n_estimators=150,\n",
    "    max_depth=7,\n",
    "    min_samples_split=4,\n",
    "    min_samples_leaf=2,\n",
    "    random_state=42\n",
    ")\n",
    "rf_model.fit(X_train, y_train)\n",
    "rf_pred = rf_model.predict(X_test)\n",
    "\n",
    "rf_mae = mean_absolute_error(y_test, rf_pred)\n",
    "rf_rmse = np.sqrt(mean_squared_error(y_test, rf_pred))\n",
    "rf_r2 = r2_score(y_test, rf_pred)\n",
    "\n",
    "mae_improvement = ((baseline_mae - rf_mae) / baseline_mae) * 100\n",
    "\n",
    "print(f\"Baseline (7-Day Moving Avg) -> MAE: £{baseline_mae:,.2f} | RMSE: £{baseline_rmse:,.2f}\")\n",
    "print(f\"Random Forest Regressor     -> MAE: £{rf_mae:,.2f} | RMSE: £{rf_rmse:,.2f} | R²: {rf_r2:.3f}\")\n",
    "print(f\"Random Forest Improvement:   +{mae_improvement:.2f}% (MAE Reduction)\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 6. Feature Importance (Sales Drivers)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "importances = pd.DataFrame({\n",
    "    'feature': feature_cols,\n",
    "    'importance': rf_model.feature_importances_\n",
    "}).sort_values('importance', ascending=False)\n",
    "\n",
    "display(importances)\n",
    "\n",
    "plt.figure(figsize=(9, 4))\n",
    "plt.barh(importances.sort_values('importance')['feature'], importances.sort_values('importance')['importance'], color='#2563eb')\n",
    "plt.title('Drivers of Sales (Random Forest Feature Importance)', fontweight='bold')\n",
    "plt.xlabel('Importance')\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 7. Recursive Future 30-Day Forecasting"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "history = clean_data[['date', target_col]].copy()\n",
    "future_dates = pd.date_range(\n",
    "    start=history['date'].max() + pd.Timedelta(days=1),\n",
    "    periods=30,\n",
    "    freq='D'\n",
    ")\n",
    "\n",
    "future_preds = []\n",
    "for f_date in future_dates:\n",
    "    day_of_week = f_date.dayofweek\n",
    "    day_of_month = f_date.day\n",
    "    month = f_date.month\n",
    "    is_weekend = int(day_of_week in [5, 6])\n",
    "    \n",
    "    vals = history[target_col].values\n",
    "    lag_1, lag_2, lag_3, lag_7, lag_14 = vals[-1], vals[-2], vals[-3], vals[-7], vals[-14]\n",
    "    rolling_mean_7 = np.mean(vals[-7:])\n",
    "    rolling_std_7 = np.std(vals[-7:])\n",
    "    rolling_mean_14 = np.mean(vals[-14:])\n",
    "    \n",
    "    row = {\n",
    "        'day_of_week': day_of_week, 'day_of_month': day_of_month, 'month': month, 'is_weekend': is_weekend,\n",
    "        'lag_1': lag_1, 'lag_2': lag_2, 'lag_3': lag_3, 'lag_7': lag_7, 'lag_14': lag_14,\n",
    "        'rolling_mean_7': rolling_mean_7, 'rolling_std_7': rolling_std_7, 'rolling_mean_14': rolling_mean_14\n",
    "    }\n",
    "    X_step = pd.DataFrame([row])[feature_cols]\n",
    "    pred = float(rf_model.predict(X_step)[0])\n",
    "    if day_of_week == 5: pred = 0.0  # Saturday closed\n",
    "    else: pred = max(0.0, pred)\n",
    "    \n",
    "    future_preds.append({\n",
    "        'date': f_date.strftime('%Y-%m-%d'),\n",
    "        'day_name': f_date.strftime('%A'),\n",
    "        'predicted_sales_revenue_gbp': round(pred, 2)\n",
    "    })\n",
    "    history = pd.concat([history, pd.DataFrame([{'date': f_date, target_col: pred}])], ignore_index=True)\n",
    "\n",
    "forecast_df = pd.DataFrame(future_preds)\n",
    "display(forecast_df.head(10))\n",
    "print(f\"Total predicted 30-day sales: £{forecast_df['predicted_sales_revenue_gbp'].sum():,.2f}\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 8. Forecast Visualization"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "plt.figure(figsize=(14, 5))\n",
    "tail = clean_data.tail(60)\n",
    "plt.plot(tail['date'], tail[target_col], label='Historical Sales (£)', color='#334155', linewidth=2)\n",
    "plt.plot(pd.to_datetime(forecast_df['date']), forecast_df['predicted_sales_revenue_gbp'], label='Predicted Future 30 Days (£)', color='#10b981', linewidth=2.5, linestyle='--', marker='o')\n",
    "plt.axvline(x=tail['date'].max(), color='#ef4444', linestyle=':', label='Forecast Start')\n",
    "plt.title('Daily Sales Revenue Forecast (Next 30 Days)', fontsize=13, fontweight='bold')\n",
    "plt.ylabel('Net Sales Revenue (£)')\n",
    "plt.legend()\n",
    "plt.xticks(rotation=45)\n",
    "plt.tight_layout()\n",
    "plt.show()"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "name": "python",
   "version": "3.13"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}

target_path = Path(r"d:\Ahsan Rafique\Internship\Ahsan Rafique-AI Engineer codecelix\AI Decision Intelligence\Project\Sales_Forecasting_and_Recommendations\notebooks\01_Sales_Forecasting_Pipeline.ipynb")
target_path.parent.mkdir(parents=True, exist_ok=True)
with open(target_path, "w", encoding="utf-8") as f:
    json.dump(notebook_content, f, indent=1)
print("Notebook written successfully to:", target_path)
